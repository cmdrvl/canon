//! Measurement harness over Canon's existing geometry kernels. No acquisition.
use canon::geo::{
    GeoCanonicalGeometryMm, GeoCanonicalPolygonMm, GeoFeatureValue, GeoGeometryTileRequest,
    GeoLinearRingMm, GeoPointLocation, GeoPointMm, materialize_geometry_tile,
};
use serde_json::{Value, json};
use std::{collections::BTreeMap, error::Error, io::Read};

fn polygon_location(
    frame: &str,
    polygon: &GeoCanonicalPolygonMm,
    point: GeoPointMm,
) -> Result<GeoPointLocation, Box<dyn Error>> {
    let ring = |vertices: &[GeoPointMm]| {
        let mut closed = vertices.to_vec();
        if closed.first() != closed.last() {
            closed.push(closed[0]);
        }
        GeoLinearRingMm::new(frame, closed)
    };
    let outer = ring(&polygon.exterior.vertices)?.locate_point(frame, point)?;
    if outer != GeoPointLocation::Interior {
        return Ok(outer);
    }
    for hole in &polygon.holes {
        match ring(&hole.vertices)?.locate_point(frame, point)? {
            GeoPointLocation::Interior => return Ok(GeoPointLocation::Exterior),
            GeoPointLocation::Boundary => return Ok(GeoPointLocation::Boundary),
            GeoPointLocation::Exterior => {}
        }
    }
    Ok(GeoPointLocation::Interior)
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut bytes = Vec::new();
    std::io::stdin().read_to_end(&mut bytes)?;
    let request: GeoGeometryTileRequest = serde_json::from_slice(&bytes)?;
    let tile = materialize_geometry_tile(&request)?;
    let mut points = BTreeMap::new();
    let mut polygons = BTreeMap::new();
    for feature in &tile.features {
        let GeoFeatureValue::Geometry { value } = &feature.value;
        match &value.geometry {
            GeoCanonicalGeometryMm::Point { coordinate } => {
                points.insert(feature.feature_id.clone(), *coordinate);
            }
            GeoCanonicalGeometryMm::Polygon { polygon } => {
                polygons.insert(feature.feature_id.clone(), vec![polygon]);
            }
            GeoCanonicalGeometryMm::MultiPolygon { polygons: parts } => {
                polygons.insert(feature.feature_id.clone(), parts.iter().collect());
            }
        }
    }
    let mut relations: BTreeMap<String, Vec<Value>> = BTreeMap::new();
    for (point_id, point) in points {
        let mut hits = Vec::new();
        for (polygon_id, parts) in &polygons {
            let mut location = GeoPointLocation::Exterior;
            for part in parts {
                match polygon_location(&tile.frame.frame_id, part, point)? {
                    GeoPointLocation::Interior => {
                        location = GeoPointLocation::Interior;
                        break;
                    }
                    GeoPointLocation::Boundary => location = GeoPointLocation::Boundary,
                    GeoPointLocation::Exterior => {}
                }
            }
            if location != GeoPointLocation::Exterior {
                hits.push(json!({"polygon_id": polygon_id, "location": location}));
            }
        }
        relations.insert(point_id, hits);
    }
    println!("{}", serde_json::to_string(&json!({"geometry_tile": tile, "point_memberships": relations}))?);
    Ok(())
}
