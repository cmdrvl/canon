#!/usr/bin/env -S uv run --script --python 3.12
# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = ["matplotlib==3.10.6"]
# ///
"""Draw the retained canonical geometry, with evidence points at their source locations."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

p = argparse.ArgumentParser()
p.add_argument("--root", type=Path, required=True)
a = p.parse_args()
root = a.root
data = json.loads((root / "geometry.json").read_bytes())
features = {f["feature_id"]: f["value"]["value"] for f in data["geometry_tile"]["features"]}
parcel_ids = {hit["polygon_id"] for hits in data["point_memberships"].values() for hit in hits if hit["polygon_id"].startswith("parcel:")}
assert len(parcel_ids) == 1
parcel_id = next(iter(parcel_ids))
box = features[parcel_id]["bbox"]
ox, oy = box["min_x"], box["min_y"]
def coords(vertices):
    return [((v["x"]-ox)/1000, (v["y"]-oy)/1000) for v in vertices]
def parts(geometry):
    return geometry["polygons"] if geometry["kind"] == "multi_polygon" else [geometry["polygon"]]

plt.rcParams.update({"font.family": "DejaVu Sans", "svg.hashsalt": "cornerstone-national-v0"})
fig, ax = plt.subplots(figsize=(8,9))
ax.set_facecolor("#fafaf7")
for id_, value in features.items():
    if not id_.startswith("building:"):
        continue
    for part in parts(value["geometry"]):
        ax.add_patch(Polygon(coords(part["exterior"]["vertices"]), facecolor="#d8dce0", edgecolor="#a8b0b8", linewidth=.6))
        for hole in part.get("holes", []):
            ax.add_patch(Polygon(coords(hole["vertices"]), facecolor="#fafaf7", edgecolor="#a8b0b8", linewidth=.6))
for part in parts(features[parcel_id]["geometry"]):
    ax.add_patch(Polygon(coords(part["exterior"]["vertices"]), facecolor="none", edgecolor="#228657", linewidth=2.5, label="Corroborated parcel"))
colors = {"fsq:": "#1759b0", "overture:": "#7b35a5", "county-address:": "#b9540b"}
labels = {"fsq:": "Foursquare: 2409 S Conway Rd", "overture:": "Overture place: 2409 Conway Rd", "county-address:": "County / Overture address: 2409 Conway Rd"}
offsets = {"fsq:": (8,14), "overture:": (-5,20), "county-address:": (-30,-28)}
for id_, value in features.items():
    if value["geometry"]["kind"] != "point":
        continue
    prefix = next(k for k in colors if id_.startswith(k))
    color = colors[prefix]
    for hit in data["point_memberships"][id_]:
        if hit["polygon_id"].startswith("building:"):
            for part in parts(features[hit["polygon_id"]]["geometry"]):
                ax.add_patch(Polygon(coords(part["exterior"]["vertices"]), facecolor=color, alpha=.30, edgecolor=color, linewidth=2))
    point = coords([value["geometry"]["coordinate"]])[0]
    ax.scatter(*point, color=color, s=55, edgecolor="white", linewidth=1, zorder=5)
    ax.annotate(labels[prefix], point, xytext=offsets[prefix], textcoords="offset points", fontsize=9,
                color=color, bbox={"facecolor":"white", "alpha":.9, "edgecolor":"none", "pad":3})
ax.set_xlim(-60,(box["max_x"]-ox)/1000+65)
ax.set_ylim(-40,(box["max_y"]-oy)/1000+45)
ax.set_aspect("equal")
ax.set_xlabel("Metres east from parcel bounding-box corner")
ax.set_ylabel("Metres north from parcel bounding-box corner")
ax.set_title("Cornerstone: same parcel, different building evidence", loc="left", fontsize=15, pad=16)
ax.text(0,1.01,"Parcel " + parcel_id.removeprefix("parcel:"), transform=ax.transAxes, fontsize=10, color="#228657")
fig.text(.10,.035,"Orange County parcels (2026-09-17); Overture buildings (2026-07-22.0, OSM / Microsoft / USGS).\nFoursquare places (2026-08-11); Overture places and addresses (2026-07-22.0).\nCanonical integer geometry in projected UTM 17N; point accuracy is uncalibrated.\nHighlighted buildings are association candidates, not a complete property building set.", fontsize=8, color="#454b52")
fig.subplots_adjust(bottom=.14,top=.92,left=.12,right=.98)
fig.savefig(root / "footprints.svg", metadata={"Date": None})
fig.savefig(root / "verification/footprints.png", dpi=120)
print(root / "footprints.svg")
