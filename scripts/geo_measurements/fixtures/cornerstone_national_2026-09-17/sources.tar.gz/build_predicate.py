#!/usr/bin/env python3
"""Compile the measurement harness using exact rlib paths from Cargo JSON output."""
import argparse
import json
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--messages", type=Path, required=True)
p.add_argument("--output", type=Path, required=True)
a = p.parse_args()
libs = {}
for line in a.messages.read_text().splitlines():
    message = json.loads(line)
    if message.get("reason") != "compiler-artifact":
        continue
    name = message["target"]["name"]
    if name in ("canon", "serde_json"):
        for filename in message["filenames"]:
            if filename.endswith(".rlib"):
                libs[name] = Path(filename).resolve()
assert set(libs) == {"canon", "serde_json"}, libs
subprocess.run(["rustc", "--edition=2024", "-C", "opt-level=2", "-C", "panic=abort",
                str(Path(__file__).with_name("predicate.rs")),
                "--extern", "canon=" + str(libs["canon"]),
                "--extern", "serde_json=" + str(libs["serde_json"]),
                "-L", "dependency=" + str(libs["serde_json"].parent), "-o", str(a.output.resolve())], check=True)
