#!/usr/bin/env python3
"""Check retained-input determinism, mirror deduplication, and geometry negatives."""
import argparse
import copy
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--canon", type=Path, required=True)
    p.add_argument("--predicate", type=Path, required=True)
    a = p.parse_args()
    root = a.root.resolve()
    variants = ["foursquare-parcel", "national-parcel", "national-building"]
    inputs = ["rows", "question", "inventory", "profile", "budget", "capabilities", "plan", "home", "section", "separation", "next"]
    checked = []
    for mode in ["replay", "duplicate-mirror"]:
        dest = Path(tempfile.mkdtemp(prefix="canon-national-" + mode + "-"))
        shutil.copytree(root / "sources", dest / "sources")
        if mode == "duplicate-mirror":
            path = dest / "sources/national-dataset-results.json"
            data = json.loads(path.read_bytes())
            rows = data["queries"]["overture_address_cornerstone"]["result"]["rows"]
            rows.extend(copy.deepcopy(rows))
            path.write_text(json.dumps(data))
        result = subprocess.run(["uv", "run", "--script", str(root / "prepare.py"), "--root", str(dest),
                                 "--canon", str(a.canon.resolve()), "--predicate", str(a.predicate.resolve())], capture_output=True)
        assert result.returncode == 0, result.stderr.decode()
        names = inputs if mode == "replay" else ["rows"]
        for variant in variants:
            for name in names:
                expected = (root / (variant + "-supported") / (name + ".json")).read_bytes()
                actual = (dest / variant / (name + ".json")).read_bytes()
                assert expected == actual, (mode, variant, name)
                checked.append({"mode": mode, "variant": variant, "artifact": name,
                                "sha256": hashlib.sha256(actual).hexdigest()})
        if mode == "replay":
            for name in ["projection", "geometry-request", "geometry", "national-profile", "support"]:
                assert (root / (name + ".json")).read_bytes() == (dest / (name + ".json")).read_bytes(), name

    request = json.loads((root / "geometry-request.json").read_bytes())
    frame = request["frame"]
    # Coordinates use the same affine origin but independent tiny synthetic shapes.
    def xy(x, y):
        return {"x": str(400000 + x), "y": str(3000000 + y)}
    def ring(x0, y0, x1, y1):
        return [xy(x0,y0), xy(x1,y0), xy(x1,y1), xy(x0,y1), xy(x0,y0)]
    def feature(id_, g):
        return {"feature_id": id_, "source_crs": frame["source_crs"], "geometry": g}
    request["features"] = [feature("shape", {"kind": "multi_polygon", "polygons": [
        {"exterior": ring(0,0,10,10), "holes": [ring(2,2,4,4)]},
        {"exterior": ring(20,20,30,30), "holes": []}]})]
    cases = {"interior": (1,1,"interior"), "hole": (3,3,None), "boundary": (0,0,"boundary"),
             "hole-boundary": (2,3,"boundary"), "second-part": (25,25,"interior"), "outside": (15,15,None)}
    for name, (x,y,_) in cases.items():
        request["features"].append(feature(name, {"kind": "point", "coordinate": xy(x,y)}))
    payload = json.dumps(request).encode()
    results = [subprocess.run([str(a.predicate.resolve())], input=payload, capture_output=True) for _ in range(2)]
    assert all(r.returncode == 0 for r in results), [r.stderr.decode() for r in results]
    assert results[0].stdout == results[1].stdout
    observed = json.loads(results[0].stdout)["point_memberships"]
    for name, (_,_,location) in cases.items():
        assert observed[name] == ([{"polygon_id": "shape", "location": location}] if location else []), (name, observed[name])
    result = {"checked_input_artifacts": checked, "geometry_cases": observed,
              "geometry_fresh_process_bytes_equal": True, "source_support_geometry_replay_equal": True,
              "duplicate_county_mirror_changes_no_evidence_rows": True}
    (root / "verification/adapter-replay.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"input_checks": len(checked), "geometry_checks": len(cases), "status": "passed"}))


if __name__ == "__main__":
    main()
