#!/usr/bin/env python3
"""Run the existing Geo DAG with supplied rows; inspect and check native resume."""
import argparse
import datetime
import hashlib
import json
import subprocess
import time
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--work-dir", type=Path, required=True)
    p.add_argument("--canon", type=Path, required=True)
    a = p.parse_args()
    root, canon = a.work_dir.resolve(), a.canon.resolve()
    req = json.loads((root / "rows.json").read_bytes())
    level = req["profile"]["selection_level"]
    args = [str(canon), "geo", "run", "--plan", str(root / "plan.json"), "--work-dir", str(root / "run")]
    for node, binding, file in [("home_cells", "rows", "home.json"), ("section", "request", "section.json"),
                              ("materialize_evidence", "rows", "rows.json"), ("separation", "request", "separation.json"),
                              ("next_evidence", "request", "next.json")]:
        args += ["--input", f"geo.{level}.{node}:{binding}={root / file}"]
    record = {"argv": args, "binary_sha256": sha(canon), "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "input_sha256": {n: sha(root / n) for n in ["rows.json", "home.json", "section.json", "separation.json", "next.json", "plan.json"]}}
    start = time.monotonic()
    result = subprocess.run(args, capture_output=True)
    record.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start)
    def save(name, value):
        (root / name).write_text(json.dumps(value, indent=2) + "\n")
    (root / "run.json").write_bytes(result.stdout)
    (root / "run.stderr").write_bytes(result.stderr)
    save("execution.json", record)
    assert result.returncode in (0, 1), result.stdout.decode() + result.stderr.decode()
    run = json.loads(result.stdout)
    assert run["status"] != "FAILED", run.get("blockers")
    result = subprocess.run([str(canon), "geo", "inspect", "--run", str(root / "run")], capture_output=True)
    (root / "inspect.json").write_bytes(result.stdout)
    (root / "inspect.stderr").write_bytes(result.stderr)
    assert result.returncode in (0, 1), result.stdout.decode()
    stage_dir = root / "run/geo" / level
    paths = sorted(stage_dir.glob("*.json"))
    assert len(paths) == 9, [p.name for p in paths]
    before = {f.name: sha(f) for f in paths}
    solve = json.loads((stage_dir / "solve.json").read_bytes())
    compiled = json.loads((stage_dir / "compile_evidence.json").read_bytes())
    ranked = solve["soft_ranked"]
    best = [r for r in ranked if r["cost"] == ranked[0]["cost"]] if ranked else []
    readback = {"read_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "variant": root.name,
                "level": level, "stage_sha256": before, "solver_status": solve["status"], "solver_summary": solve["summary"],
                "ranked_count": len(ranked), "best_count": len(best), "best_candidates": best[:10],
                "cost_histogram": {str(cost): sum(r["cost"] == cost for r in ranked) for cost in sorted({r["cost"] for r in ranked})},
                "soft_preferences": compiled["composition_request"]["soft_preferences"],
                "hard_constraints": compiled["composition_request"]["hard_constraints"], "run_status": run["status"]}
    save("readback.json", readback)
    print(json.dumps(readback), flush=True)
    result = subprocess.run(args, capture_output=True)
    (root / "resume.json").write_bytes(result.stdout)
    (root / "resume.stderr").write_bytes(result.stderr)
    assert result.returncode in (0, 1), result.stdout.decode()
    assert before == {f.name: sha(f) for f in paths}, "Native stage bytes changed on resume"
    readback["resume_stage_bytes_unchanged"] = True
    readback["resume_status"] = json.loads(result.stdout)["status"]
    save("readback.json", readback)
    print(json.dumps({"variant": root.name, "resume_stage_bytes_unchanged": True}), flush=True)


if __name__ == "__main__":
    main()
