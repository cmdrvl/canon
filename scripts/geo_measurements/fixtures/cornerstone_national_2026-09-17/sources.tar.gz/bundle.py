#!/usr/bin/env python3
"""Retain the executed experiment; refuse to claim an unfinished quality gate."""
import argparse
import gzip
import hashlib
import json
import re
import shutil
import tarfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--root", type=Path, required=True)
p.add_argument("--destination", type=Path, required=True)
a = p.parse_args()
r, d = a.root.resolve(), a.destination.resolve()
d.mkdir(exist_ok=True, parents=True)
load = lambda name: json.loads((r / name).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
gate = load("verification/quality-gate.json")
assert [g["check"] for g in gate] == ["fmt", "clippy", "tests"] and all(g["exit_code"] == 0 for g in gate), gate
counts = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", (r / "verification/tests.log").read_text())
totals = dict(zip(["passed", "failed", "ignored"], [sum(int(row[i]) for row in counts) for i in range(3)]))
assert totals["failed"] == 0 and totals["passed"] > 0
variants = ["foursquare-parcel", "national-parcel", "national-building"]
runs = {}
for suffix in ["", "-supported"]:
    for v in variants:
        name = v + suffix
        result = load(name + "/readback.json")
        assert result["resume_stage_bytes_unchanged"] and result["run_status"] == "ABSTAINED"
        resume = load(name + "/resume.json")["project_run_report"]
        assert len(resume["resumed_nodes"]) == 9 and not resume["executed_nodes"], resume
        assert len(result["hard_constraints"]) == 1
        assert result["solver_summary"]["residual_model_count_complete"]
        for filename, expected in result["stage_sha256"].items():
            assert sha(r / name / "run/geo" / result["level"] / filename) == expected
        result["execution"] = load(name + "/execution.json")
        for filename, expected in result["execution"]["input_sha256"].items():
            assert sha(r / name / filename) == expected, (name, filename)
        result["resumed_nodes"] = 9
        runs[name] = result
assert runs["foursquare-parcel-supported"]["best_count"] == 1
assert runs["national-parcel-supported"]["best_candidates"][0]["model"] == runs["foursquare-parcel-supported"]["best_candidates"][0]["model"]
assert runs["national-building-supported"]["best_count"] == 2
assert runs["national-parcel-supported"]["cost_histogram"] == {"0": 1, "2": 2982}
assert runs["national-building-supported"]["cost_histogram"] == {"1": 2, "2": 345}

source_files = sorted((r / "sources").rglob("*")) + [r / n for n in ["prepare.py", "predicate.rs", "build_predicate.py", "run_native.py", "check_adapter.py", "plot.py", "bundle.py", "national-profile.json"]]
run_files = []
for name in [*runs, "initial-diagnostic-encoding", "verification"]:
    run_files.extend(sorted((r / name).rglob("*")))
run_files += [r / n for n in ["projection.json", "geometry-request.json", "geometry.json", "geometry.stderr", "support.json", "adapter-checks.json"]]
run_files = [f for f in run_files if f.name not in ["predicate-rebuild", "predicate-from-cargo"]]
manifest = {}
for archive, paths in [("sources.tar.gz", source_files), ("run.tar.gz", run_files)]:
    files = sorted({f for f in paths if f.is_file()})
    entries = [{"path": str(f.relative_to(r)), "bytes": f.stat().st_size, "sha256": sha(f)} for f in files]
    with (d / archive).open("wb") as output, gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as zipped, tarfile.open(fileobj=zipped, mode="w") as tar:
        for f in files:
            info = tar.gettarinfo(str(f), arcname=str(f.relative_to(r)))
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.mtime = 0
            with f.open("rb") as content:
                tar.addfile(info, content)
    manifest[archive] = {"sha256": sha(d / archive), "bytes": (d / archive).stat().st_size, "files": entries}
shutil.copy2(r / "footprints.svg", d / "footprints.svg")
measurement = {
    "experiment": "cornerstone_national_2026-09-17", "bead": "bd-ie4t",
    "proof_class": "known-subject diagnostic using freshly acquired national rows and retained regional inputs; offline native replay",
    "runtime_revision": "db72dfac5d6689bb8789f81ad93c5dad9339601e",
    "workspace_head_before_measurement": "9955498", "runtime_changed": False,
    "profile": load("national-profile.json"), "subject": load("sources/supplied-address.json"),
    "prior_experiment": load("sources/prior-experiment.json"),
    "source_place_readings": len(load("support.json")["places_examined"]),
    "matched_place_readings": [{k: p[k] for k in ["id", "family", "name", "address", "match_reasons", "lineage", "ref"]} for p in load("support.json")["matched_places"]],
    "geometry_memberships": load("support.json")["memberships"],
    "geometry_kernel": "existing canon::geo materialize_geometry_tile and GeoLinearRingMm::locate_point, invoked by retained Rust measurement harness",
    "projection": load("projection.json"), "building_inventory_count": len(load("sources/overture-buildings.json")["records"]),
    "final_runs": {n: x for n,x in runs.items() if n.endswith("-supported")},
    "initial_diagnostic_runs": {n: x for n,x in runs.items() if not n.endswith("-supported")},
    "native_status": "ABSTAINED; preferences do not force identity", "hard_narrowing_criterion_met": False,
    "complete_property_building_set_claimed": False, "source_count_is_confidence": False,
    "quality_gate": gate, "rust_test_totals": totals, "adapter_verification": load("verification/adapter-replay.json"),
    "harness_rebuild": load("verification/harness-rebuild.json"),
    "cost_limitation": "Concurrent runs and tests; timings are observations, not throughput/scale proof. Initial diagnostic attempts are included separately.",
    "archives": manifest, "map_sha256": sha(d / "footprints.svg")}
(d / "measurement.json").write_text(json.dumps(measurement, indent=2, sort_keys=True) + "\n")
# Read every archive entry back and bind it to the retained manifest.
for archive, info in manifest.items():
    expected = {f["path"]: f for f in info["files"]}
    with tarfile.open(d / archive, "r:gz") as tar:
        assert set(tar.getnames()) == set(expected)
        for member in tar:
            data = tar.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest() == expected[member.name]["sha256"], member.name
print(json.dumps({"archives": {n: {k:v[k] for k in ["bytes","sha256"]} for n,v in manifest.items()}, "tests": totals, "status": "verified"}, indent=2))
