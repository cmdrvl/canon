#!/usr/bin/env -S uv run --script --python 3.12
# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = ["blake3==1.0.5", "h3==4.3.1", "pyproj==3.7.1"]
# ///
"""Offline national-place measurement adapter into existing Canon Geo rows.

The caller supplies retained source records. Matching and admission policy are
versioned here, outside core. Canon's existing integer geometry library evaluates
the point/polygon relations; the ordinary native DAG compiles and solves rows.
No target parcel/building ID appears in the matching or support rules.
"""
import argparse
import copy
import hashlib
import json
import subprocess
from pathlib import Path

import blake3
import h3
import pyproj


def encoded(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":")).encode() + b"\n"


def digest(x):
    return blake3.blake3(x if isinstance(x, bytes) else encoded(x)).hexdigest()


def write(path, x):
    path.write_bytes(encoded(x))


def fold(s):
    return " ".join(s.lower().split()) if s else None


def address_key(s):
    """Declared narrow US street comparison; missing direction never matches one.

    Whole street only, with explicit first directional and last suffix tokens.
    Unit/range/cross-street forms stay literal; no bag of tokens or fuzzy score.
    """
    if not s:
        return None
    tokens = fold(s).split()
    directions = {"north": "n", "south": "s", "east": "e", "west": "w"}
    suffixes = {"road": "rd", "street": "st", "avenue": "ave", "drive": "dr"}
    if len(tokens) >= 3 and tokens[0].isdigit():
        tokens[1] = directions.get(tokens[1], tokens[1])
        tokens[-1] = suffixes.get(tokens[-1], tokens[-1])
    return " ".join(tokens)


def record_ref(source, id_, vintage, payload):
    return {"source_record_id": source + ":" + id_, "source_vintage": vintage,
            "record_blake3": digest(payload)}


def matches(place, subject):
    # Missing locality is not agreement. ZIP+state or city+state can scope a POI.
    same_region = fold(place["region"]) == fold(subject["region"])
    local = same_region and (fold(place["locality"]) == fold(subject["locality"])
                            or (place["postcode"] or "")[:5] == subject["postal_code"][:5])
    if not local or place.get("closed"):
        return []
    reasons = []
    if fold(place["name"]) == fold(subject["property_name"]):
        reasons.append("exact_name_after_case_whitespace")
    if address_key(place["address"]) == address_key(subject["address"]):
        reasons.append("declared_us_direction_suffix_address_agreement")
    if subject["source_url"] in place["websites"]:
        reasons.append("exact_supplied_operator_url")
    return reasons


def check_policy():
    assert address_key("2409 South Conway Rd") == address_key("2409 S Conway Road")
    assert address_key("2409 South Conway Rd") != address_key("2409 Conway Rd")
    assert address_key("2409 South Conway Rd") != address_key("2409 North Conway Rd")
    assert address_key("2409 South Conway Rd") != address_key("2409 South Conway St")
    assert address_key("2409 S Conway Rd Apt 2") != address_key("2409 S Conway Rd")
    assert fold("Cornerstone") != fold("Cornerstone Pizza")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--canon", type=Path, required=True)
    p.add_argument("--predicate", type=Path, required=True)
    a = p.parse_args()
    root, canon = a.root.resolve(), a.canon.resolve()
    sources = root / "sources"
    load = lambda name: json.loads((sources / name).read_bytes())
    subject = load("supplied-address.json")
    check_policy()
    evidence = load("national-dataset-results.json")["queries"]
    places = []
    for row in evidence["fsq_cornerstone"]["result"]["rows"]:
        places.append({"id": "fsq:" + row["FSQ_PLACE_ID"], "family": "foursquare",
                       "name": row["NAME"], "address": row["ADDRESS"],
                       "locality": row["LOCALITY"], "region": row["REGION"],
                       "postcode": row["POSTCODE"], "websites": [],
                       "closed": row["DATE_CLOSED"], "longitude": row["LONGITUDE"],
                       "latitude": row["LATITUDE"], "lineage": ["foursquare"],
                       "ref": record_ref("foursquare", row["FSQ_PLACE_ID"], row["RELEASE_DT"], row),
                       "raw": row})
    for row in evidence["overture_places_cornerstone_compact"]["result"]["rows"]:
        addresses = json.loads(row["ADDRESSES"] or "[]")
        # Each asserted address stays its own reading, never a number/street cross product.
        for index, address in enumerate(addresses):
            primary = json.loads(row["PRIMARY_SOURCE"])
            places.append({"id": "overture:" + row["PROVIDER_FEATURE_ID"] + ":" + str(index),
                           "family": "overture_places", "name": json.loads(row["NAMES_JSON"])["primary"],
                           "address": address.get("freeform"), "locality": address.get("locality"),
                           "region": address.get("region"), "postcode": address.get("postcode"),
                           "websites": json.loads(row["WEBSITES"] or "[]"),
                           "longitude": row["CENTROID_LON"], "latitude": row["CENTROID_LAT"],
                           "lineage": [primary["dataset"]],
                           "ref": record_ref("overture.places", row["PROVIDER_FEATURE_ID"], row["RELEASE"], row),
                           "raw": row})
    matched = []
    for place in places:
        place["match_reasons"] = matches(place, subject)
        if place["match_reasons"]:
            matched.append(place)
    assert matched, "No supplied national place record supports the subject"
    # A deliberately wrong street and a wrong-name record cannot earn support.
    wrong = copy.deepcopy(matched[0])
    wrong.update(name="Unrelated property", address="2409 S Another Rd", websites=[])
    assert not matches(wrong, subject)
    wrong.update(name=subject["property_name"], region="CA", locality="Elsewhere", postcode="99999")
    assert not matches(wrong, subject)

    county_points = load("county-address-points.json")["features"]
    overture_addresses = evidence["overture_address_cornerstone"]["result"]["rows"]
    address_links = []
    for place in matched:
        for row in county_points:
            attrs = row["attributes"]
            if address_key(place["address"]) != address_key(attrs["COMPLETE_ADDRESS"]):
                continue
            if attrs["ADDRESS_STATUS"] != "Active" or attrs["ZIPCODE"] != subject["postal_code"]:
                continue
            refs = [place["ref"], record_ref("orange.address", str(attrs["OBJECTID"]), "2026-09-17", row)]
            mirrors = []
            for mirror in overture_addresses:
                payload = json.loads(mirror["ROW_PAYLOAD_JSON"])
                mirror_address = payload["number"] + " " + payload["street"]
                if address_key(mirror_address) == address_key(attrs["COMPLETE_ADDRESS"]) and payload["postcode"] == attrs["ZIPCODE"]:
                    refs.append(record_ref("overture.addresses", mirror["PROVIDER_FEATURE_ID"], mirror["RELEASE"], mirror))
                    mirrors.append(mirror["PROVIDER_FEATURE_ID"])
            address_links.append({"place_id": place["id"], "parcel_id": attrs["OFFICIAL_PARCEL_ID"],
                                  "point_id": "county-address:" + str(attrs["OBJECTID"]),
                                  "longitude": row["geometry"]["x"], "latitude": row["geometry"]["y"],
                                  "refs": refs, "mirrors": mirrors})
    points = {p["id"]: (p["longitude"], p["latitude"]) for p in matched}
    points.update({p["point_id"]: (p["longitude"], p["latitude"]) for p in address_links})
    # External projection only. Canon receives explicit fixed decimal planar coordinates.
    transform = pyproj.Transformer.from_crs("EPSG:4326", "EPSG:32617", always_xy=True)
    def coordinate(xy):
        x, y = transform.transform(*xy)
        return {"x": f"{x:.6f}", "y": f"{y:.6f}"}
    def polygon(rings):
        return {"exterior": [coordinate(v) for v in rings[0]],
                "holes": [[coordinate(v) for v in ring] for ring in rings[1:]]}
    def feature(id_, geometry):
        return {"feature_id": id_, "source_crs": "EPSG:32617", "geometry": geometry}
    features = [feature(id_, {"kind": "point", "coordinate": coordinate(xy)}) for id_, xy in sorted(points.items())]
    county = load("candidate-parcels.json")
    parcel_geometries = {}
    bbox_skipped = 0
    for row in county["features"]:
        rings = row["geometry"]["rings"]
        xs = [v[0] for ring in rings for v in ring]
        ys = [v[1] for ring in rings for v in ring]
        if not any(min(xs) <= x <= max(xs) and min(ys) <= y <= max(ys) for x, y in points.values()):
            bbox_skipped += 1
            continue
        # This measurement supports single exterior ArcGIS rows. Unsupported
        # rings refuse instead of silently dropping a hole/part.
        assert len(rings) == 1, "ArcGIS multi-ring geometry requires an explicit part/hole adapter"
        id_ = row["attributes"]["PARCEL"]
        parcel_geometries.setdefault(id_, []).append(polygon(rings))
    for id_, parts in sorted(parcel_geometries.items()):
        features.append(feature("parcel:" + id_, {"kind": "multi_polygon", "polygons": parts}))
    buildings = load("overture-buildings.json")["records"]
    assert len(buildings) == load("overture-buildings.json")["denominator"]["rows"][0]["FEATURES"]
    for b in buildings:
        g = b["geometry"]
        if g["type"] == "Polygon":
            geom = {"kind": "polygon", **polygon(g["coordinates"])}
        elif g["type"] == "MultiPolygon":
            geom = {"kind": "multi_polygon", "polygons": [polygon(rings) for rings in g["coordinates"]]}
        else:
            raise ValueError("Unsupported building geometry " + g["type"])
        features.append(feature("building:" + b["id"], geom))
    projection = {"pyproj_version": pyproj.__version__, "proj_version": pyproj.proj_version_str,
                  "definition": transform.definition, "source_crs": "EPSG:4326", "target_crs": "EPSG:32617",
                  "decimal_places": 6, "source_point_accuracy": "unknown; containment support stays soft",
                  "upstream_transform_accuracy_metres": transform.accuracy}
    write(root / "projection.json", projection)
    geometry_request = {"version": "canon_geo_geometry_request.v0", "frame": {
        "version": "canon_geo_local_frame.v0", "frame_id": "national.us.utm17.orlando.v0",
        "tile_id": "cornerstone-supplied-evidence", "source_crs": "EPSG:32617", "source_axis_domain": "planar",
        "source_decimal_places": 6, "source_origin": {"x": 400000000000, "y": 3000000000000},
        "affine": {"x_from_source_x_numerator": 1000, "x_from_source_y_numerator": 0,
                   "y_from_source_x_numerator": 0, "y_from_source_y_numerator": 1000, "denominator": 1000000},
        "projection": {"method_id": "supplied-planar-metre-to-mm", "method_version": "1",
                       "parameters_blake3": digest(projection), "max_projection_error_micrometres": 0},
        "max_abs_coordinate_mm": 1000000000}, "features": features,
        "max_vertices_per_geometry": 100000, "max_geometry_bytes_per_tile": 100000000}
    write(root / "geometry-request.json", geometry_request)
    result = subprocess.run([str(a.predicate.resolve())], input=encoded(geometry_request), capture_output=True)
    (root / "geometry.json").write_bytes(result.stdout)
    (root / "geometry.stderr").write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode()
    geometry = json.loads(result.stdout)
    memberships = geometry["point_memberships"]
    profile = {"profile_id": "national_place_support.v0", "mode": "experimental_offline_adapter",
               "admission": "uncalibrated soft; one preference over the supported member set per upstream place family",
               "name_comparison": "Unicode lowercase and whitespace; no article removal",
               "address_comparison": "declared first directional and final suffix abbreviations; preserve absence, units, ranges",
               "url_comparison": "exact supplied property URL", "county_address_mirror": "shared lineage, no extra preference",
               "geometry": "Canon integer predicates after explicit external projection; no point accuracy inferred",
               "scope": "one associated parcel/building hypothesis; no complete-property cardinality claim"}
    write(root / "national-profile.json", profile)
    write(root / "support.json", {"subject": subject, "profile": profile, "places_examined": places,
                                  "matched_places": matched, "address_links": address_links,
                                  "memberships": memberships, "bbox_rejected_geometry_rows": bbox_skipped})
    base = load("baseline-evidence.json")
    template = lambda n: load("native-templates/" + n + ".json")
    def command(out, argv):
        result = subprocess.run([str(canon), *map(str, argv)], capture_output=True)
        out.write_bytes(result.stdout)
        out.with_suffix(".stderr").write_bytes(result.stderr)
        assert result.returncode in (0, 1), result.stdout.decode() + result.stderr.decode()
        return json.loads(result.stdout)
    for variant, level, families in [("foursquare-parcel", "parcel", {"foursquare"}),
                                     ("national-parcel", "parcel", {"foursquare", "overture_places"}),
                                     ("national-building", "building", {"foursquare", "overture_places"})]:
        work = root / variant
        work.mkdir(exist_ok=True)
        (work / "run").mkdir(exist_ok=True)
        ids = sorted({r["attributes"]["PARCEL"] for r in county["features"]}) if level == "parcel" else sorted(b["id"] for b in buildings)
        selection_profile = {"version": "canon_geo_composition_profile.v0", "selection_level": level}
        contracts = [copy.deepcopy(base["contracts"][0])]
        contracts[0]["id"] = "national:single-association-hypothesis"
        contracts[0]["method_id"] = profile["profile_id"]
        contracts[0]["source_dataset"] = "caller-question"
        contracts[0]["source_release"] = "national-association-experiment.v0"
        contracts[0]["source_lineage_ids"] = ["caller-question"]
        refs = [record_ref("supplied", "subject", subject["source_vintage"], subject),
                record_ref("measurement", "profile", "v0", profile)]
        evidence_rows = [{"observation_id": "national:single-association-hypothesis", "contract_id": contracts[0]["id"],
                          "source_record": ref, "observation": {"kind": "exact_cardinality", "level": level, "count": 1}} for ref in refs]
        supports = {}
        for place in matched:
            if place["family"] not in families:
                continue
            found = {r["polygon_id"].removeprefix(level + ":") for r in memberships[place["id"]]
                     if r["polygon_id"].startswith(level + ":")}
            found_refs = [place["ref"], *refs]
            lineage = set(place["lineage"] + ["bh-property-operator"])
            if level == "parcel":
                lineage.add("orange-county-property-appraiser")
            else:
                lineage.add("OpenStreetMap")
            for link in address_links:
                if link["place_id"] != place["id"]:
                    continue
                found_refs.extend(link["refs"])
                lineage.update(["orange-county-property-appraiser", "OpenAddresses/FL/Orange County"])
                if level == "parcel":
                    assert link["parcel_id"] in ids
                    found.add(link["parcel_id"])
                else:
                    found.update(r["polygon_id"].removeprefix("building:") for r in memberships[link["point_id"]]
                                 if r["polygon_id"].startswith("building:"))
            if found:
                entry = supports.setdefault(place["family"], {"refs": {}, "lineage": set(), "members": set()})
                entry["members"].update(found)
                for ref in found_refs:
                    entry["refs"][ref["source_record_id"]] = ref
                entry["lineage"].update(lineage)
        for family, support in sorted(supports.items()):
            # Include the geometry bytes in every spatial-support observation.
            support["refs"]["measurement:geometry"] = record_ref("measurement", "geometry", "v0", geometry)
            support["refs"]["measurement:raw-parcels"] = record_ref("measurement", "raw-parcels", "2026-09-17", county)
            if level == "building":
                support["refs"]["measurement:raw-buildings"] = record_ref("measurement", "raw-buildings", "2026-07-22.0", buildings)
            contract_id = "national:" + family
            contracts.append({"id": contract_id, "version": "1", "source_dataset": family,
                              "source_release": "supplied-retained-records", "source_lineage_ids": sorted(support["lineage"]),
                              "method_id": profile["profile_id"], "method_version": "1", "claim_role": "attribute_observation",
                              "basis": {"kind": "uncalibrated", "reason": "Place identity and coordinate accuracy uncalibrated; spatial/text support cannot force identity",
                                        "admission_policy": {"kind": "soft_with_weight", "cost_if_absent": 1}}})
            observation = {"kind": "existential_membership", "members": [{"level": level, "id": id_} for id_ in sorted(support["members"])]}
            for ref in support["refs"].values():
                evidence_rows.append({"observation_id": contract_id, "contract_id": contract_id,
                                      "source_record": ref, "observation": observation})
        rows = {"version": "canon_geo_warehouse_rows.v0", "profile": selection_profile,
                "parcel_rows": [{"parcel_id": id_} for id_ in ids] if level == "parcel" else [],
                "building_parcel_rows": [{"building_id": id_, "parcel_id": None} for id_ in ids] if level == "building" else [],
                "contracts": contracts, "evidence_rows": evidence_rows, "max_assignments": 20000000, "max_materialized_models": 4000}
        write(work / "rows.json", rows)
        question, inventory, budget = [template(n) for n in ["question", "inventory", "budget"]]
        question["question_id"] = "national-place-associated-" + level
        question["subject_bindings"].append({"binding_class": "operator_label", "role": "supplied-address", "value": subject["address"]})
        question["requested_grains"][0].update(entity_level=level, required_evidence_classes=["parcel_geometry" if level == "parcel" else "building_footprint"],
                                               optional_evidence_classes=["asserted_attribute", "address_set", "address_string", "geocode_point"])
        # The composition implementation's claim label remains explicit in readback;
        # this measurement asks association hypotheses, not complete collateral.
        source = inventory["sources"][0]
        if level == "building":
            region = {"geography_id": "orlando.supplied-address-window", "geography_kind": "bounded_box",
                      "description": "Overture building bbox intersects [-81.335,28.512,-81.326,28.520], H3r4 8444a91ffffffff"}
            question["bounded_geography"] = inventory["region"] = region
            source["coverage"]["region"] = region
            source["coverage"]["predicate"] = region["description"]
            source["source_instance_id"] = "overture.buildings"
            source["native_scope"]["entity_level"] = "building"
            source["lineage_ids"] = ["OpenStreetMap", "Overture"]
            source["release"] = {"release_id": "2026-07-22.0", "release_digest": "blake3:" + digest((sources / "overture-buildings.json").read_bytes())}
            source["evidence_classes"] = ["building_footprint", "asserted_attribute"]
            source["license_class"] = "public_attribution_required"
            source["geometry"] = {"geometry_contract_version": "overture.geojson.retained.v0",
                                  "coordinate_reference_system": "EPSG:4326", "transform_id": "source-native-wgs84",
                                  "transform_digest": "blake3:" + digest(buildings), "numeric_error_bounds": []}
        source["estimates"][0]["value"] = len(ids)
        source["local_state"]["local_ref"]["content_hash"] = "blake3:" + digest((work / "rows.json").read_bytes())
        for family in sorted(families):
            observations = [p for p in places if p["family"] == family]
            inventory["sources"].append({
                "source_instance_id": family, "release": {
                    "release_id": observations[0]["ref"]["source_vintage"], "release_digest": "blake3:" + digest(observations)},
                "temporal_scope": {}, "lineage_ids": sorted({line for p in observations for line in p["lineage"]}),
                "native_scope": {"kind": "observation_only"},
                "evidence_classes": ["asserted_attribute", "address_string", "geocode_point"],
                "coverage": {"coverage_id": family + ".retained-subject-query", "region": inventory["region"],
                             "predicate": "Only retained subject-name/address query results; no complete regional place coverage claim"},
                "license_class": "unknown", "egress_class": "derived_only",
                "local_state": copy.deepcopy(source["local_state"]),
                "estimates": [{"origin": "local_artifact", "semantic_id": "retained_observations", "unit": "row", "value": len(observations)}]})
        for name, value in [("question", question), ("inventory", inventory), ("profile", selection_profile), ("budget", budget)]:
            write(work / (name + ".json"), value)
        command(work / "capabilities.json", ["geo", "capabilities"])
        plan = command(work / "plan.json", ["geo", "plan", "--question", work / "question.json", "--inventory", work / "inventory.json",
                                            "--profile", work / "profile.json", "--budget", work / "budget.json", "--capabilities", work / "capabilities.json"])
        assert plan["status"] == "planned", plan
        binding = {"source_instance_id": source["source_instance_id"], "release": source["release"],
                   "native_scope": source["native_scope"], "inventory_ref": plan["inventory_ref"]}
        if level == "parcel":
            home, section = template("home"), template("section")
            for row in home["rows"]:
                row["source"] = binding
            for row in section["features"]:
                row["source"] = binding
        else:
            home = {"version": "canon_geo_home_cell_rows.v1", "coordinate_crs": "EPSG:4326", "coordinate_decimal_places": 9,
                    "h3_resolution": 7, "stability_radius_fixed": 0, "rows": [], "max_rows": 4000}
            section = {"version": "canon_geo_tile_work_request.v1", "center_cell": h3.latlng_to_cell(28.516, -81.330, 7),
                       "halo_k": 2, "features": [], "max_features": 4000, "max_work_cells": 10000}
            for b in buildings:
                cell = h3.latlng_to_cell(b["latitude"], b["longitude"], 7)
                home["rows"].append({"source": binding, "feature_id": b["id"], "source_record_id": b["id"],
                                     "geometry_sha256": hashlib.sha256(encoded(b["geometry"])).hexdigest(),
                                     "representative_point_method": "source-centroid-blocking-only", "longitude": f'{b["longitude"]:.9f}',
                                     "latitude": f'{b["latitude"]:.9f}', "claimed_home_cell": cell})
                section["features"].append({"source": binding, "feature_id": b["id"], "home_cell": cell})
        write(work / "home.json", home)
        write(work / "section.json", section)
        halves = [ids[:len(ids)//2], ids[len(ids)//2:]]
        separation = {"version": "canon_geo_separation_inputs.v0", "prospective": [{"id": "future-parcel-membership",
                      "contract_id": "prospective.member-partition", "cost_units": 1,
                      "outcomes": [{"outcome_id": str(i), "induced": [{"kind": "allowed_sets", "level": level, "sets": [[id_] for id_ in half]}]}
                                   for i, half in enumerate(halves)]}]}
        write(work / "separation.json", separation)
        next_ = template("next")
        next_["budget"] = budget
        write(work / "next.json", next_)
        print(json.dumps({"variant": variant, "candidates": len(ids), "soft_supports": len(supports)}), flush=True)
    write(root / "adapter-checks.json", {"directional_positive": True, "directional_absence_negative": True,
          "opposite_direction_negative": True, "different_street_negative": True, "unit_distinction": True,
          "wrong_name_and_street_negative": True, "wrong_region_negative": True,
          "mirror_policy": "mirror rows only extend existing observation provenance, never create preferences"})


if __name__ == "__main__":
    main()
