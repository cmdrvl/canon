#!/usr/bin/env python3
"""Collect the six real native runs without changing any resolution request."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


cases = []
for index in range(3):
    root = ROOT / f"case-{index}"
    address = read(root / "supplied-address.json")
    point_rows = read(root / "county-address-points.json")["features"]
    assert len(point_rows) == 1
    reference = point_rows[0]["attributes"]
    reference_id = reference["OFFICIAL_PARCEL_ID"]
    prelookup = read(root / "hints/prelookup-readback.json")
    case = {"index": index, "property": address["property_name"], "operator_address": address,
            "county_address_reference": reference,
            "reference_limit": "Number/basename query; missing South makes Cornerstone a diagnostic reference candidate, not exact operator-address membership" if index == 1 else "Exact recorded street address linked to parcel by county source; no complete property extent claim",
            "prelookup_readback": prelookup, "runs": {}}
    for variant in ["hints", "address"]:
        path = root / variant
        run = read(path / "run.json")
        resume = read(path / "resume.json")
        back = read(path / "readback.json")
        assert back["resume_stage_bytes_unchanged"]
        assert len(resume["project_run_report"]["resumed_nodes"]) == 9
        assert not resume["project_run_report"]["executed_nodes"]
        assert not run["project_run_report"]["failed_nodes"]
        assert len(run["project_run_report"]["executed_nodes"]) + len(run["project_run_report"]["resumed_nodes"]) == 9
        request = read(path / "descriptive.json")
        solve = read(path / "run/geo/parcel/solve.json")
        compiled = read(path / "run/geo/parcel/compile_evidence.json")
        rows = solve["soft_ranked"]
        best = [row for row in rows if row["cost"] == rows[0]["cost"]]
        costs = sorted({row["cost"] for row in rows})
        ids = {candidate["id"] for candidate in request["candidates"]}
        models = solve["residual_models"]
        assert ids == {model["parcels"][0] for model in models}
        assert all(len(model["parcels"]) == 1 and not model["buildings"] for model in models)
        assert len(ids) == len(models) == 2983
        if variant == "hints":
            assert sha(path / "run/geo/parcel/solve.json") == prelookup["solve_sha256"]
            assert sha(path / "descriptive.json") == prelookup["descriptive_sha256"]
        record = {"status": run["status"], "solver_status": solve["status"],
                  "exact_hard_residual": solve["summary"]["residual_model_count"],
                  "residual_count_complete": solve["summary"]["residual_model_count_complete"],
                  "residual_count_saturated": solve["summary"]["residual_model_count_saturated"],
                  "theoretical_assignment_count_saturated": solve["summary"]["candidate_assignments_saturated"],
                  "all_inventory_parcels_retained": True, "reference_candidate_retained": reference_id in ids,
                  "hard_forced": solve["hard_forced"], "hard_constraint_count": len(compiled["composition_request"]["hard_constraints"]),
                  "unknown_candidate_unit_counts": sum(c["attributes"]["unit_count"] is None for c in request["candidates"]),
                  "soft_preference_count": len(compiled["composition_request"]["soft_preferences"]),
                  "best_model_count": len(best), "best_and_next_distinct_cost": costs[:2],
                  "unique_best_is_reference": len(best) == 1 and best[0]["model"]["parcels"] == [reference_id],
                  "best_candidates": back["best_candidates"] if len(best) <= 10 else [],
                  "blind_experiment_success": False,
                  "admissions": [{"observation_id": entry["observation_id"],
                                  "disposition": entry["disposition"],
                                  "generated_ids": entry.get("generated_ids", []),
                                  "contract": entry["contract"],
                                  "source_record_count_provenance_only": len(entry["source_records"])}
                                 for entry in compiled["admissions"]],
                  "execution": read(path / "execution.json"),
                  "interrupted_numeric_mask_execution": read(path / "numeric-mask-interrupted/execution.json"),
                  "executed_stages": run["project_run_report"]["executed_nodes"],
                  "resumed_stages": run["project_run_report"]["resumed_nodes"],
                  "resume_reused_stages": resume["project_run_report"]["resumed_nodes"],
                  "stage_sha256": back["stage_sha256"], "resume_stage_bytes_unchanged": True,
                  "inspection_sha256": sha(path / "inspect.json"),
                  "next_evidence": read(path / "run/geo/parcel/next_evidence.json")}
        case["runs"][variant] = record
    h, a = case["runs"]["hints"], case["runs"]["address"]
    case["hints_discovery_and_supplied_address_corroboration"] = h["unique_best_is_reference"] and a["unique_best_is_reference"] and a["soft_preference_count"] > h["soft_preference_count"]
    cases.append(case)

measurement = {"proof_class": "retained-public-data-experiment", "code": read(ROOT / "binary.json"),
               "selection": read(ROOT / "selection.json"), "initial_geometry_rows": 2992,
               "distinct_parcel_candidates": 2983, "property_denominator": 3,
               "hints_discovery_and_address_corroboration_count": sum(c["hints_discovery_and_supplied_address_corroboration"] for c in cases),
               "accepted_identity_count": 0,
               "native_policy": "Same soft name/address policy as db72dfa; all candidate residential unit counts unknown; no target alias or directional rewrite",
               "assembly_replay": read(ROOT / "assembly-replay-checks.json"),
               "comparison_checks": read(ROOT / "comparison-checks.json"), "cases": cases,
               "prospective_representation_equivalence": read(ROOT / "prospective-equivalence.json"),
               "interruption": read(ROOT / "numeric-mask-interruption.json"),
               "limits": ["Geography-selected three-property replication, not portfolio accuracy or scale acceptance",
                          "Current assessor snapshot does not establish December 2025 physical truth",
                          "DOR03 county subset and single-parcel premise do not establish complete reach or property extent",
                          "Native statuses remain ABSTAINED; soft costs are neither probabilities nor independent source counts",
                          "Cornerstone's directional mismatch is unresolved, not normalized away",
                          "Source-count/measure calibration, source-neutral accepted membership, and automated accepted identity remain open"]}
(ROOT / "measurement.json").write_text(json.dumps(measurement, indent=2) + "\n")
print(json.dumps({"cases": len(cases), "hints_and_address_positive": measurement["hints_discovery_and_address_corroboration_count"], "accepted_identity_count": 0}))
