#!/usr/bin/env -S uv run --script --python 3.12
# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = ["blake3==1.0.5", "h3==4.3.1", "shapely==2.1.1"]
# ///
"""Offline, retained Orange County experiment input assembly; no acquisition.

Templates are the unchanged Courtney experiment's native contracts. County
metadata, candidate rows, and subject bindings are explicitly replaced below.
No target lookup, name aliasing, or land-quantity-to-unit conversion occurs.
"""
import argparse
import collections
import copy
import hashlib
import json
import subprocess
from pathlib import Path

import blake3
import h3
from shapely.geometry import Polygon
from shapely.ops import unary_union


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode() + b"\n"


def digest(raw):
    return blake3.blake3(raw).hexdigest()


def write(path, value):
    path.write_bytes(encoded(value))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--sources", type=Path, required=True)
    p.add_argument("--work-dir", type=Path, required=True)
    p.add_argument("--subject-index", type=int, required=True)
    p.add_argument("--canon", type=Path, required=True)
    p.add_argument("--address-evidence", type=Path)
    a = p.parse_args()
    a.canon = a.canon.resolve()
    root = a.work_dir.resolve()
    root.mkdir(parents=True, exist_ok=True)
    (root / "run").mkdir(exist_ok=True)
    source_root = a.sources.resolve()
    selection_raw = (source_root / "selection.json").read_bytes()
    selection = json.loads(selection_raw)
    ordered = sorted(selection["cohort"], key=lambda x: hashlib.sha256((selection["selection_seed"] + x["property_name"]).encode()).hexdigest())
    assert ordered == selection["ordered_subjects"]
    claim = ordered[a.subject_index]
    raw = (source_root / "candidate-parcels.json").read_bytes()
    data = json.loads(raw)
    assert not data["exceededTransferLimit"]
    grouped = collections.defaultdict(list)
    for row in data["features"]:
        assert row["attributes"]["DOR_CODE"].startswith("03")
        grouped[row["attributes"]["PARCEL"]].append(row)
    ids = sorted(grouped)
    assert len(ids) <= 4000
    templates = source_root / "templates"
    load = lambda name: json.loads((templates / (name + ".json")).read_bytes())
    release = {"release_id": "retained-" + digest(raw)[:16], "release_digest": "blake3:" + digest(raw)}
    region = {"geography_id": "us.fl.orange.dor03", "geography_kind": "county_assessor_subset", "description": "All returned Orange County Florida parcels with DOR_CODE LIKE '03%'; no target predicate"}
    inventory_rows = load("inventory-rows")
    inventory_rows["parcel_rows"] = [{"parcel_id": id_} for id_ in ids]
    inventory_rows.update(max_assignments=20_000_000, max_materialized_models=4000)
    write(root / "inventory-rows.json", inventory_rows)
    question, inventory, budget, profile = [load(n) for n in ["question", "inventory", "budget", "profile"]]
    question["subject_bindings"][0]["value"] = claim["property_name"]
    question["bounded_geography"] = region
    inventory["region"] = region
    inv_source = inventory["sources"][0]
    inv_source.update(source_instance_id="orange.assessor.parcels", lineage_ids=["orange-county-property-appraiser"], release=release)
    inv_source["coverage"].update(region=region, predicate="DOR_CODE LIKE '03%'")
    inv_source["estimates"][0]["value"] = len(ids)
    inv_source["local_state"]["local_ref"]["content_hash"] = "blake3:" + digest((root / "inventory-rows.json").read_bytes())
    for bound in budget["deterministic_bounds"]:
        if bound["counter"] in ["candidates", "variables", "models"]:
            bound["value"] = 4000
        if bound["counter"] == "states":
            bound["value"] = 20_000_000
        if bound["counter"] == "operations":
            bound["value"] = 200_000_000
    for name, value in [("question", question), ("inventory", inventory), ("budget", budget), ("profile", profile)]:
        write(root / (name + ".json"), value)
    def command(name, args):
        result = subprocess.run([str(a.canon), *map(str, args)], capture_output=True)
        (root / (name + ".json")).write_bytes(result.stdout)
        (root / (name + ".stderr")).write_bytes(result.stderr)
        assert result.returncode in (0, 1), result.stdout.decode() + result.stderr.decode()
        return json.loads(result.stdout)
    command("capabilities", ["geo", "capabilities"])
    plan = command("plan", ["geo", "plan", "--question", root / "question.json", "--capabilities", root / "capabilities.json", "--inventory", root / "inventory.json", "--profile", root / "profile.json", "--budget", root / "budget.json"])
    assert plan["status"] == "planned" and not plan["external_requests"]
    source = {"source_instance_id": inv_source["source_instance_id"], "release": release, "native_scope": inv_source["native_scope"], "inventory_ref": plan["inventory_ref"]}
    candidates, homes, features, conflicts = [], [], [], []
    for id_ in ids:
        rows = sorted(grouped[id_], key=lambda r: r["attributes"]["OBJECTID"])
        def agreed(field):
            vals = {r["attributes"][field].strip() if isinstance(r["attributes"][field], str) else r["attributes"][field] for r in rows}
            if len(vals) != 1:
                conflicts.append({"parcel": id_, "field": field, "values": sorted(map(str, vals))})
                return None
            return next(iter(vals)) or None
        geometry = [r["geometry"] for r in rows]
        polygon = unary_union([Polygon(ring) for g in geometry for ring in g["rings"]])
        point = polygon.centroid
        lon, lat = f"{point.x:.9f}", f"{point.y:.9f}"
        cell = h3.latlng_to_cell(float(lat), float(lon), 7)
        homes.append({"source": source, "feature_id": id_, "source_record_id": ",".join(str(r["attributes"]["OBJECTID"]) for r in rows), "geometry_sha256": hashlib.sha256(encoded(geometry)).hexdigest(), "representative_point_method": "regional-parcel-part-union-centroid-blocking-only", "longitude": lon, "latitude": lat, "claimed_home_cell": cell})
        features.append({"source": source, "feature_id": id_, "home_cell": cell})
        attrs = {"property_name": agreed("PROP_NAME"), "address": agreed("SITUS"), "property_type": "multifamily", "unit_count": None, "year_built": agreed("AYB")}
        if attrs["year_built"] is not None and attrs["year_built"] <= 0:
            attrs["year_built"] = None
        candidates.append({"id": id_, "attributes": attrs, "source_records": [{"source_record_id": "ocpa:" + str(r["attributes"]["OBJECTID"]), "source_vintage": release["release_id"], "record_blake3": digest(encoded(r))} for r in rows]})
    center = h3.latlng_to_cell(28.54, -81.38, 7)
    halo = max(h3.grid_distance(center, f["home_cell"]) for f in features)
    write(root / "home.json", {"version": "canon_geo_home_cell_rows.v1", "coordinate_crs": "EPSG:4326", "coordinate_decimal_places": 9, "h3_resolution": 7, "stability_radius_fixed": 0, "rows": homes, "max_rows": 4000})
    write(root / "section.json", {"version": "canon_geo_tile_work_request.v1", "center_cell": center, "halo_k": halo, "features": features, "max_features": 4000, "max_work_cells": 10000})
    request = load("descriptive")
    request.update(bounded_geography=region, inventory_source=source, candidates=candidates, max_candidates=4000, max_assignments=20_000_000, max_materialized_models=4000)
    request["claim"]["attributes"] = {"property_name": claim["property_name"], "property_type": "multifamily", "unit_count": claim["unit_count"], "year_built": None}
    request["claim"]["source_records"][-1]["record_blake3"] = digest(selection_raw)
    for policy in request["profile"]["channels"]:
        policy["contract"]["source_release"] = release["release_id"]
        policy["contract"]["source_lineage_ids"] = sorted(["orange-county-property-appraiser", "nxrt-company-disclosure"])
    if a.address_evidence:
        address_raw = a.address_evidence.read_bytes()
        address = json.loads(address_raw)
        assert address["property_name"] == claim["property_name"] and address["geography_id"] == region["geography_id"]
        request["claim"]["attributes"]["address"] = address["address"]
        request["claim"]["source_records"].append({"source_record_id": address["source_url"], "source_vintage": address["source_vintage"], "record_blake3": digest(address_raw)})
        for policy in request["profile"]["channels"]:
            if policy["channel"] == "address":
                policy["contract"]["source_lineage_ids"] = sorted(["orange-county-property-appraiser", address["lineage_id"]])
    write(root / "descriptive.json", request)
    # Hypothetical future parcel-membership observation; never acquired evidence.
    # Split all IDs into exhaustive disjoint halves without using target hints.
    first = set(ids[:len(ids) // 2])
    # Under the fixed exactly-one-parcel premise, these singleton sets are
    # identical to the original zero-sum 0/1 partition masks. Explicit sets
    # avoid repeatedly cloning every dense numeric member value during DFS.
    outcomes = [{"outcome_id": label, "induced": [{"kind": "allowed_sets", "level": "parcel", "sets": [[id_] for id_ in ids if (id_ in first) == side]}]} for label, side in [("first_half", True), ("second_half", False)]]
    write(root / "separation.json", {"version": "canon_geo_separation_inputs.v0", "prospective": [{"id": "future-parcel-membership", "contract_id": "prospective.parcel-id-partition", "cost_units": 1, "outcomes": outcomes}]})
    next_ = load("next")
    next_["budget"] = budget
    next_["candidates"][0].update(action_id="acquire-source-parcel-membership", observation_id="future-parcel-membership", kind={"kind": "observe", "payload": "future-parcel-membership"})
    write(root / "next.json", next_)
    argv = [str(a.canon), "geo", "run", "--plan", str(root / "plan.json"), "--work-dir", str(root / "run")]
    for node, binding, file in [("home_cells", "rows", "home.json"), ("section", "request", "section.json"), ("materialize_evidence", "rows", "descriptive.json"), ("separation", "request", "separation.json"), ("next_evidence", "request", "next.json")]:
        argv += ["--input", f"geo.parcel.{node}:{binding}={root / file}"]
    write(root / "run-command.json", argv)
    write(root / "adapter-observations.json", {"rows": len(data["features"]), "parcels": len(ids), "duplicate_geometry_rows_merged": len(data["features"]) - len(ids), "attribute_conflicts_kept_unknown": conflicts, "unit_policy": "unknown for all: LAND_QTY is land valuation quantity, not declared residential unit count", "halo_k": halo, "center": "fixed Orlando market coordinate; blocking only"})
    print(json.dumps({"property": claim["property_name"], "candidates": len(ids), "halo_k": halo, "work_dir": str(root)}))


if __name__ == "__main__":
    main()
