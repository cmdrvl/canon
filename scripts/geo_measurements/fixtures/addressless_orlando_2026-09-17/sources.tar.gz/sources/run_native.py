#!/usr/bin/env python3
"""Run the archived native DAG, inspect in a fresh process, and check resume."""
import argparse
import datetime
import hashlib
import json
import subprocess
import time
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--work-dir", type=Path, required=True)
    p.add_argument("--canon", type=Path, required=True)
    a = p.parse_args()
    root = a.work_dir.resolve()
    (root / "run").mkdir(exist_ok=True)
    canon = a.canon.resolve()
    args = [str(canon), "geo", "run", "--plan", str(root / "plan.json"), "--work-dir", str(root / "run")]
    for node, binding, file in [("home_cells", "rows", "home.json"), ("section", "request", "section.json"), ("materialize_evidence", "rows", "descriptive.json"), ("separation", "request", "separation.json"), ("next_evidence", "request", "next.json")]:
        args += ["--input", f"geo.parcel.{node}:{binding}={root / file}"]
    record = {"argv": args, "binary_sha256": sha(canon), "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "input_sha256": {f.name: sha(f) for f in sorted(root.glob("*.json")) if f.name not in ["run-command.json", "execution.json", "run.json", "inspect.json", "resume.json", "readback.json"]}}
    start = time.monotonic()
    result = subprocess.run(args, capture_output=True)
    record.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start)
    (root / "run.json").write_bytes(result.stdout)
    (root / "run.stderr").write_bytes(result.stderr)
    (root / "execution.json").write_text(json.dumps(record, indent=2) + "\n")
    assert result.returncode in (0, 1), result.stdout.decode() + result.stderr.decode()
    run = json.loads(result.stdout)
    assert run["status"] != "FAILED", run.get("blockers")
    inspection = subprocess.run([str(canon), "geo", "inspect", "--run", str(root / "run")], capture_output=True)
    (root / "inspect.json").write_bytes(inspection.stdout)
    (root / "inspect.stderr").write_bytes(inspection.stderr)
    assert inspection.returncode in (0, 1), inspection.stdout.decode()
    paths = sorted((root / "run/geo/parcel").glob("*.json"))
    before = {f.name: sha(f) for f in paths}
    solve = json.loads((root / "run/geo/parcel/solve.json").read_bytes())
    req = json.loads((root / "descriptive.json").read_bytes())
    compiled = json.loads((root / "run/geo/parcel/compile_evidence.json").read_bytes())
    ranked = solve["soft_ranked"]
    best = [r for r in ranked if r["cost"] == ranked[0]["cost"]] if ranked else []
    attrs = {r["id"]: r["attributes"] for r in req["candidates"]}
    readback = {"read_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "property": req["claim"]["attributes"]["property_name"], "supplied_address": req["claim"]["attributes"].get("address"), "stage_sha256": before, "solver_status": solve["status"], "solver_summary": solve["summary"], "ranked_count": len(ranked), "best_count": len(best), "best_candidates": [{"parcel_ids": r["model"]["parcels"], "cost": r["cost"], "attributes": [attrs[id_] for id_ in r["model"]["parcels"]]} for r in best[:10]], "soft_preferences": compiled["composition_request"]["soft_preferences"], "hard_constraint_count": len(compiled["composition_request"]["hard_constraints"])}
    (root / "readback.json").write_text(json.dumps(readback, indent=2) + "\n")
    print(json.dumps(readback), flush=True)
    result = subprocess.run(args, capture_output=True)
    (root / "resume.json").write_bytes(result.stdout)
    (root / "resume.stderr").write_bytes(result.stderr)
    assert result.returncode in (0, 1), result.stdout.decode()
    after = {f.name: sha(f) for f in paths}
    assert before == after, "native stage bytes changed on resume"
    readback["resume_stage_bytes_unchanged"] = True
    readback["resume_status"] = json.loads(result.stdout)["status"]
    (root / "readback.json").write_text(json.dumps(readback, indent=2) + "\n")
    print(json.dumps({"property": readback["property"], "resume_stage_bytes_unchanged": True}), flush=True)


if __name__ == "__main__":
    main()
